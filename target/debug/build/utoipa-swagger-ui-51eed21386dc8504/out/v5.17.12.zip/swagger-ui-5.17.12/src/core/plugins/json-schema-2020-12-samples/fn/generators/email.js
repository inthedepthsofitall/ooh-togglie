/**
 * @prettier
 */
const emailGenerator = () => "user@example.com"

export default emailGenerator
